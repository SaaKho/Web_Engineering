import React from 'react';

import Posts from '../../Posts/Posts';
import Sidebar from '../../sidebar/sidebar';

import './Home.css';
function Home() {
    return (
        <>
      <div className="header">
        <div className="headerTitles">
        <span className="headerSmall"> React & Node</span>
        <span className="headerLarge"> Blog</span>
        
        </div>
        <img className="headearImage" 
        src="https://images7.alphacoders.com/362/362619.jpg" alt=''
        />
      </div>
     <div className="Home"> 
     <Posts/>
         <Sidebar/>
         </div>
      </>
   
    
      );
  }
  
  export default Home;
  