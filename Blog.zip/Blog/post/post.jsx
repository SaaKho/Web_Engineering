import React from "react";
import './post.css';
function Post() {
    return (
     <>

    <div className="posts">
    <img className="Imgpost"
    src="https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?cs=srgb&dl=pexels-pixabay-164595.jpg&fm=jpg" alt=""/> 
                 
  <div className="postInfo">
  <div className="postCats">
      <span className="postCats"> Music</span>
      <span className="postCats">Life</span>
     </div>
    <span className="postTitles"> Resturant Facilities</span>
   
    <span className="postDate">1 hour ago</span>
    <div className="PostDesc"> 
    <p > 
    Lorem ipsum, or lipsum as it is sometimes known,
     is dummy text used in laying out print, 
    graphic or web designs. The passage is attributed to an unknown
     typesetter in the 15th century who is thought to have
     scrambled parts of Cicero's De Finibus Bonorum et Malorum
      for use in a type specimen book. It usually begins with
      Lorem ipsum, or lipsum as it is sometimes known,
     is dummy text used in laying out print, 
    graphic or web designs. The passage is attributed to an unknown
     typesetter in the 15th century who is thought to have
     scrambled parts of Cicero's De Finibus Bonorum et Malorum
      for use in a type specimen book. It usually begins with::</p>
    </div>
   
    </div>
    </div>  
     </>

    );
  }
  
  export default Post;
  