
import React from "react";
import Sidebar2 from "../Sidebar2/Sidebar2";


import Singlepost from "../Singlepost/Singlepost";
function Single() {
    return (
      <div className="single">
      
       
       <Singlepost/>
     <Sidebar2/>
      
    </div>
    );
  }
  
  export default Single;